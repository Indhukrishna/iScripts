#!/usr/bin/bash
sudo dpkg -i powershell_6.1.1-1.ubuntu.16.04_amd64.deb