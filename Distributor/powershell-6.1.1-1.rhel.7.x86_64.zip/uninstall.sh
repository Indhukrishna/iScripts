#!/usr/bin/bash
sudo yum -y remove powershell