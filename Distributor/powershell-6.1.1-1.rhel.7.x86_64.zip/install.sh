#!/usr/bin/bash
sudo yum -y install powershell-6.1.1-1.rhel.7.x86_64.rpm