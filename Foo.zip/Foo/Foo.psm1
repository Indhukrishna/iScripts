function Get-Foo
{
}