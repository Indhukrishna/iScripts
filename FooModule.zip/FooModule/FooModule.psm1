function Get-FooModule
{
"FooModule"
}